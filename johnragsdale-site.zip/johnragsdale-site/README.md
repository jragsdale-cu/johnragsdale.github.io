# JOHN RAGSDALE. | Personal Brand Website

A bold, Serhant-inspired personal brand website and blog for John Ragsdale - VP of Operations, Credit Union Leader, and Strategic Advisor.

## 🚀 Quick Deploy to GitHub Pages

### Step 1: Create a GitHub Repository
1. Go to [github.com](https://github.com) and sign in
2. Click the **+** icon → **New repository**
3. Name it: `johnragsdale.github.io` (or any name you prefer)
4. Keep it **Public** (required for free GitHub Pages)
5. Click **Create repository**

### Step 2: Upload Files
**Option A: Using GitHub Web Interface (Easiest)**
1. In your new repo, click **uploading an existing file**
2. Drag and drop ALL files and folders from this site
3. Click **Commit changes**

**Option B: Using Git Command Line**
```bash
git init
git add .
git commit -m "Initial commit - John Ragsdale personal brand site"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git
git push -u origin main
```

### Step 3: Enable GitHub Pages
1. Go to your repository → **Settings**
2. Scroll to **Pages** in the left sidebar
3. Under "Source", select **Deploy from a branch**
4. Branch: **main** / Folder: **/ (root)**
5. Click **Save**

### Step 4: Access Your Site
Your site will be live at:
- `https://YOUR-USERNAME.github.io/` (if repo named `username.github.io`)
- `https://YOUR-USERNAME.github.io/REPO-NAME/` (for other repo names)

---

## 📁 File Structure

```
johnragsdale-site/
├── index.html              # Main homepage
├── blog.html               # Blog/insights listing page
├── posts/                  # Individual blog posts
│   ├── crossroads-credit-unions.html
│   └── [add more posts here]
├── assets/
│   └── images/
│       └── john-ragsdale-headshot.jpeg
└── README.md
```

---

## ✏️ How to Add New Blog Posts

### 1. Copy the template
Duplicate `posts/crossroads-credit-unions.html` and rename it (e.g., `my-new-post.html`)

### 2. Edit these sections in your new post:

**In the `<head>` section:**
```html
<title>Your Post Title | JOHN RAGSDALE.</title>
<meta name="description" content="Your post description here">
```

**In the article header:**
```html
<span class="article-category">Leadership</span>  <!-- Change category -->
<h1>YOUR POST TITLE HERE</h1>
<div class="article-meta">
    <span>By John Ragsdale</span>
    <span>•</span>
    <span>January 2025</span>  <!-- Update date -->
    <span>•</span>
    <span>5 min read</span>    <!-- Update read time -->
</div>
```

**In the article content:**
Replace the content inside `<div class="article-content">` with your writing.

### 3. Add the post to blog.html
Add a new card in the `blog-grid` section:

```html
<a href="posts/my-new-post.html" class="blog-card" data-category="leadership">
    <div class="card-image leadership">
        <span class="card-category">Leadership</span>
    </div>
    <div class="card-content">
        <span class="card-date">January 2025</span>
        <h3 class="card-title">Your Post Title</h3>
        <p class="card-excerpt">A brief description of your post...</p>
        <span class="card-link">Read More</span>
    </div>
</a>
```

### Available Categories & Colors
- `leadership` - Navy blue gradient
- `strategy` - Gold gradient
- `operations` - Deep blue gradient
- `culture` - Light blue gradient
- `books` - Steel blue gradient
- `videos` - Gold/navy gradient

---

## 🎨 Customization Guide

### Change Colors
Edit the CSS variables at the top of each HTML file:
```css
:root {
    --navy: #1a2744;        /* Primary dark color */
    --steel-blue: #4a6fa5;  /* Secondary blue */
    --gold: #c9a227;        /* Accent color */
    --cream: #faf9f6;       /* Background alt */
    --white: #ffffff;
    --charcoal: #2d2d2d;    /* Text color */
    --light-gray: #f5f5f5;  /* Light background */
}
```

### Update Contact Form
The contact form uses Formspree. To activate:
1. Go to [formspree.io](https://formspree.io)
2. Create a free account
3. Create a new form
4. Replace `your-form-id` in the form action URL:
```html
<form action="https://formspree.io/f/YOUR-FORM-ID" method="POST">
```

### Update Social Links
In `index.html`, find the social links section and update:
```html
<a href="https://www.linkedin.com/in/YOUR-LINKEDIN/" class="social-link">
<a href="mailto:YOUR-EMAIL@example.com" class="social-link">
```

---

## 📱 Features

- **Fully Responsive** - Looks great on desktop, tablet, and mobile
- **No Build Tools Required** - Pure HTML, CSS, and JavaScript
- **Fast Loading** - No frameworks, minimal dependencies
- **SEO Friendly** - Semantic HTML with meta descriptions
- **Blog Ready** - Easy-to-use post template system
- **Contact Form Ready** - Just add your Formspree ID

---

## 🔧 Optional: Custom Domain

Want to use your own domain (e.g., johnragsdale.com)?

1. Purchase a domain from Namecheap, GoDaddy, Google Domains, etc.
2. In your GitHub repo, go to **Settings → Pages**
3. Under "Custom domain", enter your domain
4. Add these DNS records at your domain registrar:
   - **A Records** pointing to GitHub's IPs:
     - 185.199.108.153
     - 185.199.109.153
     - 185.199.110.153
     - 185.199.111.153
   - **CNAME Record**: `www` → `YOUR-USERNAME.github.io`

---

## 📝 Content Ideas for Your Blog

Based on your experience, here are some post ideas:

**Leadership & Culture**
- "From 65% to 15%: The Turnover Transformation Playbook"
- "Why Culture Eats Strategy for Breakfast (And How to Feed It)"
- "The Hiring Mistakes I'll Never Make Again"

**Operations & Strategy**
- "The Outbound Lending Department: From Zero to $2M Monthly"
- "Decentralizing Loan Officers: Lessons from the Trenches"
- "Vendor Management: Cutting Costs Without Cutting Corners"

**Credit Union Industry**
- "The Future of Credit Unions in a Digital-First World"
- "Member Financial Education: ROI Beyond the Numbers"
- "What I Learned Consulting for Credit Unions Across the Southeast"

**Personal Growth**
- "Books That Changed How I Lead"
- "The Best Advice I Ever Ignored (And Why I Was Wrong)"
- "Lessons from Being the Youngest Board Member"

---

## 💡 Tips for Building Your Brand

1. **Post Consistently** - Even monthly is better than sporadic
2. **Share Your Posts** - LinkedIn is your friend
3. **Be Authentic** - Your voice is your brand
4. **Tell Stories** - Data convinces, stories connect
5. **Engage** - Respond to comments and messages

---

## 📞 Support

Questions about the site? Need help customizing?

Built with intention by Claude for John Ragsdale.

---

*"Transform. Execute. Lead."*
